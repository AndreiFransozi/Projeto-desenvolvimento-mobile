package com.example.easysnack;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ListView;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.view.View;
import android.widget.ImageView;
import java.util.ArrayList;
import android.content.Intent;

public class MainActivity extends AppCompatActivity {

    private Button Fazer_Pedido;
    private Button Historico_pedidos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button button = findViewById(R.id.button); // Assuming you have a button with id "button" in your layout

        // Initialize views
        Fazer_Pedido = findViewById(R.id.button2);
        Historico_pedidos = findViewById(R.id.button3);

        // Set click listeners for buttons
        Fazer_Pedido.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Code to be executed when button2 is clicked
                Fazer_PedidoClicked();
            }
        });

        Historico_pedidos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Code to be executed when button3 is clicked
                Historico_pedidosClicked();
            }
        });
    }

    // Methods to be executed when buttons are clicked
    private void Fazer_PedidoClicked() {
        // TO DO: implement logic for button2 click
    }

    private void Historico_pedidosClicked() {
        // TO DO: implement logic for button3 click
    }
}