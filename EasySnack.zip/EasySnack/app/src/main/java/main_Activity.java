import android.os.Bundle;
import class Food;
import class FoodAdapter;
import androidx.appcompat.app.AppCompatActivity;

public class main_Activity extends AppCompatActivity {
    public class ActiviteMainBinding {
    }

    private ActiviteMainBinding binding;
    private FoodAdapter foodAdapter;
    private Arraylist<Food> Foodlist = new arraylist<>();

    @Override
    protected void oncreate(Bundle savedInstanceState)
    super.

    onCreate(savedInstanceState);

    binding =ActiviteMainBinding.inflate(

    getLayoutInflater());

    setContentView(binding.getRoot());
    ReciclerView reciclerviewFood = binding.ReciclerViewFood;
recyclerviewFood.setLayoutManager(new

    LinearLayoutManager(this));
recyclerviewFood.setHasFixedSize(true);
    foodAdapter =new

    FoodAdapter(foodlist, context this);
recyclerviewFood.setAdapter(foodAdapter);
}
private void getFood{}{
    Food food1 = new Food{
R.drawble.food1,
foodName "Food1",
foodDescription "foodDescription",
price "$20"
    }
    foodList.add(food1);
        }


