public interface ApiService {
    @GET("endpoint")
    Call<List<Objeto>> getObjetos();

    @POST("endpoint")
    Call<Objeto> createObjeto(@Body Objeto novoObjeto);
}
